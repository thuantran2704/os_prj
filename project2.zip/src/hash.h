#ifndef __HASH_FUNCTIONS_HEADER__
#define __HASH_FUNCTIONS_HEADER__

void crack_hashed_passwords(char *password_list, char *hashed_list, char *output);

#endif
